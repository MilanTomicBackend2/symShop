<?php

/* base.html.twig */
class __TwigTemplate_54760178e2afd20d65f9beb08cc368901cb954cbe7d422100dbffaa4bf820fbf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1f783310a1181fd69e6b804e02c5feb9cb9db0845cfa4807db8a3968f0750de1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1f783310a1181fd69e6b804e02c5feb9cb9db0845cfa4807db8a3968f0750de1->enter($__internal_1f783310a1181fd69e6b804e02c5feb9cb9db0845cfa4807db8a3968f0750de1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_37ef3c9ac0702ce1d0bf57262596ad2fc68c93139c9a4a8bb2046adcf1ee9a5b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37ef3c9ac0702ce1d0bf57262596ad2fc68c93139c9a4a8bb2046adcf1ee9a5b->enter($__internal_37ef3c9ac0702ce1d0bf57262596ad2fc68c93139c9a4a8bb2046adcf1ee9a5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 11
        $this->displayBlock('body', $context, $blocks);
        // line 12
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 13
        echo "    </body>
</html>
";
        
        $__internal_1f783310a1181fd69e6b804e02c5feb9cb9db0845cfa4807db8a3968f0750de1->leave($__internal_1f783310a1181fd69e6b804e02c5feb9cb9db0845cfa4807db8a3968f0750de1_prof);

        
        $__internal_37ef3c9ac0702ce1d0bf57262596ad2fc68c93139c9a4a8bb2046adcf1ee9a5b->leave($__internal_37ef3c9ac0702ce1d0bf57262596ad2fc68c93139c9a4a8bb2046adcf1ee9a5b_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_0406b3a6a61a74fbceb95e8ae67b088f8a6f83a00832123192476ef8db598428 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0406b3a6a61a74fbceb95e8ae67b088f8a6f83a00832123192476ef8db598428->enter($__internal_0406b3a6a61a74fbceb95e8ae67b088f8a6f83a00832123192476ef8db598428_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b54560af7a1c4acf50a9351f9daf7d1cfd8b7a19fee3b859b58b5bad3ee36971 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b54560af7a1c4acf50a9351f9daf7d1cfd8b7a19fee3b859b58b5bad3ee36971->enter($__internal_b54560af7a1c4acf50a9351f9daf7d1cfd8b7a19fee3b859b58b5bad3ee36971_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_b54560af7a1c4acf50a9351f9daf7d1cfd8b7a19fee3b859b58b5bad3ee36971->leave($__internal_b54560af7a1c4acf50a9351f9daf7d1cfd8b7a19fee3b859b58b5bad3ee36971_prof);

        
        $__internal_0406b3a6a61a74fbceb95e8ae67b088f8a6f83a00832123192476ef8db598428->leave($__internal_0406b3a6a61a74fbceb95e8ae67b088f8a6f83a00832123192476ef8db598428_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0577f19457a8fdf8130e5e54ba5f60b550a1f450b8a746a264afc6180e5b2232 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0577f19457a8fdf8130e5e54ba5f60b550a1f450b8a746a264afc6180e5b2232->enter($__internal_0577f19457a8fdf8130e5e54ba5f60b550a1f450b8a746a264afc6180e5b2232_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_e8f1ebf2b146d39eacd057e3d0a51c24959d5bc0368e894edd599928b1afcaf5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8f1ebf2b146d39eacd057e3d0a51c24959d5bc0368e894edd599928b1afcaf5->enter($__internal_e8f1ebf2b146d39eacd057e3d0a51c24959d5bc0368e894edd599928b1afcaf5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        echo "<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
        
        $__internal_e8f1ebf2b146d39eacd057e3d0a51c24959d5bc0368e894edd599928b1afcaf5->leave($__internal_e8f1ebf2b146d39eacd057e3d0a51c24959d5bc0368e894edd599928b1afcaf5_prof);

        
        $__internal_0577f19457a8fdf8130e5e54ba5f60b550a1f450b8a746a264afc6180e5b2232->leave($__internal_0577f19457a8fdf8130e5e54ba5f60b550a1f450b8a746a264afc6180e5b2232_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_04d15b67bfcaa5637acb9398207542874ec9fbea38bffea649e9df199854ec0e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_04d15b67bfcaa5637acb9398207542874ec9fbea38bffea649e9df199854ec0e->enter($__internal_04d15b67bfcaa5637acb9398207542874ec9fbea38bffea649e9df199854ec0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7e4b03eba6040435027b74d185d1bdcbda3b616e2c276a407fda89ccb48aa884 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e4b03eba6040435027b74d185d1bdcbda3b616e2c276a407fda89ccb48aa884->enter($__internal_7e4b03eba6040435027b74d185d1bdcbda3b616e2c276a407fda89ccb48aa884_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_7e4b03eba6040435027b74d185d1bdcbda3b616e2c276a407fda89ccb48aa884->leave($__internal_7e4b03eba6040435027b74d185d1bdcbda3b616e2c276a407fda89ccb48aa884_prof);

        
        $__internal_04d15b67bfcaa5637acb9398207542874ec9fbea38bffea649e9df199854ec0e->leave($__internal_04d15b67bfcaa5637acb9398207542874ec9fbea38bffea649e9df199854ec0e_prof);

    }

    // line 12
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_89b6d88da487fc228d1e3fa2175e56837be5758b5eb81569d6e94158c4787bec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89b6d88da487fc228d1e3fa2175e56837be5758b5eb81569d6e94158c4787bec->enter($__internal_89b6d88da487fc228d1e3fa2175e56837be5758b5eb81569d6e94158c4787bec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_f8932dd55ebdf65f97aa61d8c1cbbcf35305fabe6f0a2219dd662be33c9a0214 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8932dd55ebdf65f97aa61d8c1cbbcf35305fabe6f0a2219dd662be33c9a0214->enter($__internal_f8932dd55ebdf65f97aa61d8c1cbbcf35305fabe6f0a2219dd662be33c9a0214_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_f8932dd55ebdf65f97aa61d8c1cbbcf35305fabe6f0a2219dd662be33c9a0214->leave($__internal_f8932dd55ebdf65f97aa61d8c1cbbcf35305fabe6f0a2219dd662be33c9a0214_prof);

        
        $__internal_89b6d88da487fc228d1e3fa2175e56837be5758b5eb81569d6e94158c4787bec->leave($__internal_89b6d88da487fc228d1e3fa2175e56837be5758b5eb81569d6e94158c4787bec_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 12,  103 => 11,  85 => 6,  67 => 5,  55 => 13,  52 => 12,  50 => 11,  44 => 8,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\"/>{% endblock %}
        
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\symShop\\app\\Resources\\views\\base.html.twig");
    }
}
