<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class ProductController extends Controller {
    
    public $products = [
	[
		'id' => 1,
		'title' => 'Lopta',
		'description' => 'Oficijelna FIVB odbojkaĹˇka lopta sa 8-panelnim dizajnom, izraÄ‘ena od veĹˇtaÄŤke koĹľe, super mekim PU mikrofiber slojem i butil mehurom sa zaĹˇtitom od curenja.',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/3507.jpg',
		'price' => 5.00,
		'category' => 'Sport',
		'homepage' => 0
	],
	[
		'id' => 2,
		'title' => 'Patike',
		'description' => 'Adidas muĹˇka cipela.',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/1587108.jpg',
		'price' => 38.00,
		'category' => 'ObuÄ‡a',
		'homepage' => 1
	],
	[
		'id' => 3,
		'title' => 'Sijalica',
		'description' => '',
		'image' => '',
		'price' => 5.00,
		'category' => 'Rasveta',
		'homepage' => 0
	],
	[
		'id' => 4,
		'title' => 'DĹľemper',
		'description' => 'Shooter muĹˇki dĹľemper MS 3301-08 - teget',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/1967108.jpg',
		'price' => 13.00,
		'category' => 'OdeÄ‡a',
		'homepage' => 1
	],
	[
		'id' => 5,
		'title' => 'Jakna',
		'description' => 'Brandit Lord jakna za prelazno vreme je sastavljena od meĹˇavine poliestera i pamuka u razmeri 65% prema 35%. Ovakav odnos ÄŤini jaknu izuzetno jakom jer su polesterska vlakna znatno jaÄŤa i otporna na spoljne faktore Ĺˇto Ä‡e produĹľiti Ĺľivotni vek vaĹˇe jakne.',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/2200038.jpg',
		'price' => 40.00,
		'category' => 'OdeÄ‡a',
		'homepage' => 1
	],
	[
		'id' => 6,
		'title' => 'Kosilica',
		'description' => 'Bosch ARM 32 elektriÄŤna kosilica za travu ima ÄŤeĹˇalj za travu koji omoguÄ‡ava da pokosite vaĹˇ travnjak savrĹˇeno do same ivice. TeĹˇka je svega 6.8 kg, pa je laka za rukovanje, dok Powerdrive-motor od 1.200 W obezbeÄ‘uje lak rad, ÄŤak i u visokoj travi.',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/58755.jpg',
		'price' => 85.00,
		'category' => 'BaĹˇta',
		'homepage' => 1
	],
	[
		'id' => 7,
		'title' => 'Bajka',
		'description' => 'DoĹˇlo je vreme da i novim generacijama Diznijeve bajke ulepĹˇavaju detinjstvo, ali i vreme da svi oni koji nisu pre tri godine upotpunili kolekciju to sada uÄŤine.',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/15314.jpg',
		'price' => 3.00,
		'category' => 'Knjige',
		'homepage' => 0
	],
	[
		'id' => 8,
		'title' => 'PaketiÄ‡',
		'description' => 'Magaza NovogodiĹˇnji paketiÄ‡ deÄŤaci 6+ I',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/16227.jpg',
		'price' => 5.00,
		'category' => 'SlatkiĹˇi',
		'homepage' => 1
	],
	[
		'id' => 9,
		'title' => 'Alkatel-4024D',
		'description' => 'Alcatel Pixi First 4024D je mobilni telefon sa dijagonalom ekrana od 4 inÄŤa, 512 MB ram memorije, Quad-core 1.2 GHz procesorom i glavnom kamerom od 5MP.',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/986866.jpg',
		'price' => 205.00,
		'category' => 'Telefoni',
		'homepage' => 1
	],
	[
		'id' => 10,
		'title' => 'Colossus-CSS-5330',
		'description' => 'Dehidrator - SuĹˇaÄŤ hrane Colossus CSS-5330',
		'image' => 'http://www.nonstopshop.rs/cms/flick/prodimg/mediadb/largeimg/12221.jpg',
		'price' => 55.00,
		'category' => 'Hrana',
		'homepage' => 1
	]
];
    
    public function listAction() {
        return $this->render('product/list.html.twig', [
            'products' => $this->products
        ]);
        
    }
    
    
    public function showAction($name) {
        
        $product = $this->findProductByTitle($name);
        
        if (!$product) {
            throw new Exception;
        }
        
        return $this->render('product/show.html.twig', ['product' => $product]);
        
    }
    
    public function findProductByTitle($title) {
        foreach ($this->products as $product) {
            if (in_array($title, $product)) {
                return $product;
            }
        }
        return false;
    }
    
    public function homepageAction(){
        
       
      
        return $this->render('product/homepage.html.twig',['homepage' => $this->products]);
    }
}
