<?php

/* product/show.html.twig */
class __TwigTemplate_dcd68230ae06d4583ff935cdc1568e912b75c90f9dd93c6a38c02786bc016b8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "product/show.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_296200d2207b906b94eb312887210af845a42e6e351beeb13db3b1c04e88a301 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_296200d2207b906b94eb312887210af845a42e6e351beeb13db3b1c04e88a301->enter($__internal_296200d2207b906b94eb312887210af845a42e6e351beeb13db3b1c04e88a301_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/show.html.twig"));

        $__internal_693fbbe9658e07786d653ef6cd5a02c8eae52d116110b5c961ee74cc84f562fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_693fbbe9658e07786d653ef6cd5a02c8eae52d116110b5c961ee74cc84f562fd->enter($__internal_693fbbe9658e07786d653ef6cd5a02c8eae52d116110b5c961ee74cc84f562fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_296200d2207b906b94eb312887210af845a42e6e351beeb13db3b1c04e88a301->leave($__internal_296200d2207b906b94eb312887210af845a42e6e351beeb13db3b1c04e88a301_prof);

        
        $__internal_693fbbe9658e07786d653ef6cd5a02c8eae52d116110b5c961ee74cc84f562fd->leave($__internal_693fbbe9658e07786d653ef6cd5a02c8eae52d116110b5c961ee74cc84f562fd_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_208b6085b6c6f7aba36b208c5d054d5d4fc45c79cb4c2c55eb4f6357cb63c8f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_208b6085b6c6f7aba36b208c5d054d5d4fc45c79cb4c2c55eb4f6357cb63c8f8->enter($__internal_208b6085b6c6f7aba36b208c5d054d5d4fc45c79cb4c2c55eb4f6357cb63c8f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_3a026f6b17751c38111a809bbbae8530be7e587da2ba453478cb2c39db557317 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a026f6b17751c38111a809bbbae8530be7e587da2ba453478cb2c39db557317->enter($__internal_3a026f6b17751c38111a809bbbae8530be7e587da2ba453478cb2c39db557317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Detalji";
        
        $__internal_3a026f6b17751c38111a809bbbae8530be7e587da2ba453478cb2c39db557317->leave($__internal_3a026f6b17751c38111a809bbbae8530be7e587da2ba453478cb2c39db557317_prof);

        
        $__internal_208b6085b6c6f7aba36b208c5d054d5d4fc45c79cb4c2c55eb4f6357cb63c8f8->leave($__internal_208b6085b6c6f7aba36b208c5d054d5d4fc45c79cb4c2c55eb4f6357cb63c8f8_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_2357597d5607a576a87e8a11144718555d3fdae6a4a7795e1cbcd037c26ae6e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2357597d5607a576a87e8a11144718555d3fdae6a4a7795e1cbcd037c26ae6e5->enter($__internal_2357597d5607a576a87e8a11144718555d3fdae6a4a7795e1cbcd037c26ae6e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_28ee3875f4f7de3c9c2676ccf928ddf79232053f28f77819e3db6049a835cdcd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28ee3875f4f7de3c9c2676ccf928ddf79232053f28f77819e3db6049a835cdcd->enter($__internal_28ee3875f4f7de3c9c2676ccf928ddf79232053f28f77819e3db6049a835cdcd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
";
        
        $__internal_28ee3875f4f7de3c9c2676ccf928ddf79232053f28f77819e3db6049a835cdcd->leave($__internal_28ee3875f4f7de3c9c2676ccf928ddf79232053f28f77819e3db6049a835cdcd_prof);

        
        $__internal_2357597d5607a576a87e8a11144718555d3fdae6a4a7795e1cbcd037c26ae6e5->leave($__internal_2357597d5607a576a87e8a11144718555d3fdae6a4a7795e1cbcd037c26ae6e5_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_0d99f3526f7a8a4f7f95e4979c73db124b06c3c04d51d3422159bff0c7f8f7ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0d99f3526f7a8a4f7f95e4979c73db124b06c3c04d51d3422159bff0c7f8f7ae->enter($__internal_0d99f3526f7a8a4f7f95e4979c73db124b06c3c04d51d3422159bff0c7f8f7ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e99574d4070cfaebe8bed6e24d6ff4c6b9fe757e199915bcec4df89f61a54836 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e99574d4070cfaebe8bed6e24d6ff4c6b9fe757e199915bcec4df89f61a54836->enter($__internal_e99574d4070cfaebe8bed6e24d6ff4c6b9fe757e199915bcec4df89f61a54836_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    
    <h2>Proizvod #";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["product"]) ? $context["product"] : $this->getContext($context, "product")), "id", array(), "array"), "html", null, true);
        echo "</h2>
    <h3>Naziv: ";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["product"]) ? $context["product"] : $this->getContext($context, "product")), "title", array(), "array"), "html", null, true);
        echo "</h3>
    <h4>Opis: ";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["product"]) ? $context["product"] : $this->getContext($context, "product")), "description", array(), "array"), "html", null, true);
        echo "</h4>
    <h5>Cena: ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["product"]) ? $context["product"] : $this->getContext($context, "product")), "price", array(), "array"), "html", null, true);
        echo "</h5>
    
    
";
        
        $__internal_e99574d4070cfaebe8bed6e24d6ff4c6b9fe757e199915bcec4df89f61a54836->leave($__internal_e99574d4070cfaebe8bed6e24d6ff4c6b9fe757e199915bcec4df89f61a54836_prof);

        
        $__internal_0d99f3526f7a8a4f7f95e4979c73db124b06c3c04d51d3422159bff0c7f8f7ae->leave($__internal_0d99f3526f7a8a4f7f95e4979c73db124b06c3c04d51d3422159bff0c7f8f7ae_prof);

    }

    public function getTemplateName()
    {
        return "product/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 14,  102 => 13,  98 => 12,  94 => 11,  91 => 10,  82 => 9,  69 => 6,  60 => 5,  42 => 3,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}
{% block title %}Detalji{% endblock %}

{% block stylesheets %}
    <link href=\"{{ asset('css/style.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>
{% endblock %}

{% block body %}
    
    <h2>Proizvod #{{ product['id'] }}</h2>
    <h3>Naziv: {{ product['title'] }}</h3>
    <h4>Opis: {{product['description']}}</h4>
    <h5>Cena: {{ product['price'] }}</h5>
    
    
{% endblock %}
", "product/show.html.twig", "C:\\xampp\\htdocs\\symShop\\app\\Resources\\views\\product\\show.html.twig");
    }
}
