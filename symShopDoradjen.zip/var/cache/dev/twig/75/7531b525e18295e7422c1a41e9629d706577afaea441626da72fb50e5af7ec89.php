<?php

/* product/homepage.html.twig */
class __TwigTemplate_522c8de18e14106c94c70f537719cadcad2e5b4f5a2c3ada2fcff4ec59ff086b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "product/homepage.html.twig", 2);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb915e0c2567f1ff064b5dbbf7b6a4450b81ccfbe0f1b21e48a834da0cca0ea0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb915e0c2567f1ff064b5dbbf7b6a4450b81ccfbe0f1b21e48a834da0cca0ea0->enter($__internal_fb915e0c2567f1ff064b5dbbf7b6a4450b81ccfbe0f1b21e48a834da0cca0ea0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/homepage.html.twig"));

        $__internal_4814c1e12185e71be02701db929c26b2ea4cab8ab66048aa73b6740a268d1c3b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4814c1e12185e71be02701db929c26b2ea4cab8ab66048aa73b6740a268d1c3b->enter($__internal_4814c1e12185e71be02701db929c26b2ea4cab8ab66048aa73b6740a268d1c3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fb915e0c2567f1ff064b5dbbf7b6a4450b81ccfbe0f1b21e48a834da0cca0ea0->leave($__internal_fb915e0c2567f1ff064b5dbbf7b6a4450b81ccfbe0f1b21e48a834da0cca0ea0_prof);

        
        $__internal_4814c1e12185e71be02701db929c26b2ea4cab8ab66048aa73b6740a268d1c3b->leave($__internal_4814c1e12185e71be02701db929c26b2ea4cab8ab66048aa73b6740a268d1c3b_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3d536298a7fd2e60eb8e4c4fcd6b130c4466842ee6c899d8d296c908605e7b8b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d536298a7fd2e60eb8e4c4fcd6b130c4466842ee6c899d8d296c908605e7b8b->enter($__internal_3d536298a7fd2e60eb8e4c4fcd6b130c4466842ee6c899d8d296c908605e7b8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_c033ab5730f7ebe6c40af8e146201a342326f720daabfe5c12a5d269525ffa22 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c033ab5730f7ebe6c40af8e146201a342326f720daabfe5c12a5d269525ffa22->enter($__internal_c033ab5730f7ebe6c40af8e146201a342326f720daabfe5c12a5d269525ffa22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
";
        
        $__internal_c033ab5730f7ebe6c40af8e146201a342326f720daabfe5c12a5d269525ffa22->leave($__internal_c033ab5730f7ebe6c40af8e146201a342326f720daabfe5c12a5d269525ffa22_prof);

        
        $__internal_3d536298a7fd2e60eb8e4c4fcd6b130c4466842ee6c899d8d296c908605e7b8b->leave($__internal_3d536298a7fd2e60eb8e4c4fcd6b130c4466842ee6c899d8d296c908605e7b8b_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_dce12434ee4d37d08be69de14608d54ac7dde425805426beb70fd53e99837b85 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dce12434ee4d37d08be69de14608d54ac7dde425805426beb70fd53e99837b85->enter($__internal_dce12434ee4d37d08be69de14608d54ac7dde425805426beb70fd53e99837b85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0c77ed35d5264cc2f5bcb1e2c89442222cbc0f8f92a563f56eeb35f92272cc45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c77ed35d5264cc2f5bcb1e2c89442222cbc0f8f92a563f56eeb35f92272cc45->enter($__internal_0c77ed35d5264cc2f5bcb1e2c89442222cbc0f8f92a563f56eeb35f92272cc45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Homepage";
        
        $__internal_0c77ed35d5264cc2f5bcb1e2c89442222cbc0f8f92a563f56eeb35f92272cc45->leave($__internal_0c77ed35d5264cc2f5bcb1e2c89442222cbc0f8f92a563f56eeb35f92272cc45_prof);

        
        $__internal_dce12434ee4d37d08be69de14608d54ac7dde425805426beb70fd53e99837b85->leave($__internal_dce12434ee4d37d08be69de14608d54ac7dde425805426beb70fd53e99837b85_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_3c6cacf3af916df6ce0c7b092b91fbe5c469ee116c4088c93ad368b53b139a58 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c6cacf3af916df6ce0c7b092b91fbe5c469ee116c4088c93ad368b53b139a58->enter($__internal_3c6cacf3af916df6ce0c7b092b91fbe5c469ee116c4088c93ad368b53b139a58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_628227af48d88348d0e24201009670de1f1052e9d173a3b660a4493239245f1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_628227af48d88348d0e24201009670de1f1052e9d173a3b660a4493239245f1c->enter($__internal_628227af48d88348d0e24201009670de1f1052e9d173a3b660a4493239245f1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
    ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["homepage"]) ? $context["homepage"] : $this->getContext($context, "homepage")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 13
            echo "        
        ";
            // line 14
            if (($this->getAttribute($context["product"], "homepage", array(), "array") == 1)) {
                // line 18
                echo "            
            
                 
            <p>";
                // line 21
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "id", array(), "array"), "html", null, true);
                echo "</p>
            <p>";
                // line 22
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array(), "array"), "html", null, true);
                echo "</p>
            <p>";
                // line 23
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "description", array(), "array"), "html", null, true);
                echo "</p>
            <p><a href=\"\">";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "image", array(), "array"), "html", null, true);
                echo "</a></p>
            <p>";
                // line 25
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "price", array(), "array"), "html", null, true);
                echo "</p>
            <p>";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "category", array(), "array"), "html", null, true);
                echo "</p>
            
        ";
            }
            // line 28
            echo "  

    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_628227af48d88348d0e24201009670de1f1052e9d173a3b660a4493239245f1c->leave($__internal_628227af48d88348d0e24201009670de1f1052e9d173a3b660a4493239245f1c_prof);

        
        $__internal_3c6cacf3af916df6ce0c7b092b91fbe5c469ee116c4088c93ad368b53b139a58->leave($__internal_3c6cacf3af916df6ce0c7b092b91fbe5c469ee116c4088c93ad368b53b139a58_prof);

    }

    public function getTemplateName()
    {
        return "product/homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 28,  128 => 26,  124 => 25,  120 => 24,  116 => 23,  112 => 22,  108 => 21,  103 => 18,  101 => 14,  98 => 13,  94 => 12,  91 => 11,  82 => 10,  64 => 8,  51 => 5,  42 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}

{% block stylesheets %}
    <link href=\"{{ asset('css/style.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>
{% endblock %}

{% block title %}Homepage{% endblock %}

{% block body %}

    {% for product in homepage %}
        
        {% if product['homepage'] == 1 %}
{# nije mi najjasnije kako da sliku ubacim 
znam da ovo sa linkom nije kako treba pokusavao sa sa 
<img src=\"{{ asset('img/products') }}\" , ali mi onda izbacuje i ove slike iz niza i one iz foldera .
#}            
            
                 
            <p>{{ product['id'] }}</p>
            <p>{{ product['title'] }}</p>
            <p>{{ product['description'] }}</p>
            <p><a href=\"\">{{ product['image'] }}</a></p>
            <p>{{ product['price'] }}</p>
            <p>{{ product['category'] }}</p>
            
        {% endif %}  

    {% endfor %}
{% endblock %}

", "product/homepage.html.twig", "C:\\xampp\\htdocs\\symShop\\app\\Resources\\views\\product\\homepage.html.twig");
    }
}
