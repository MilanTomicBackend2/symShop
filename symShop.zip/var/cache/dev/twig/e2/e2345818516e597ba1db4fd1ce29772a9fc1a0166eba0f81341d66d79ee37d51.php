<?php

/* base.html.twig */
class __TwigTemplate_54760178e2afd20d65f9beb08cc368901cb954cbe7d422100dbffaa4bf820fbf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'nav' => array($this, 'block_nav'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d67202221790f8c0fad0e1e68f0f56517c46d431c81d0791a7d1793ceb973c00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d67202221790f8c0fad0e1e68f0f56517c46d431c81d0791a7d1793ceb973c00->enter($__internal_d67202221790f8c0fad0e1e68f0f56517c46d431c81d0791a7d1793ceb973c00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_a1e90e252628d75c3292cc999a168c68539ea2eae5ee24a90d486a5511f2fa12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1e90e252628d75c3292cc999a168c68539ea2eae5ee24a90d486a5511f2fa12->enter($__internal_a1e90e252628d75c3292cc999a168c68539ea2eae5ee24a90d486a5511f2fa12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 13
        $this->displayBlock('nav', $context, $blocks);
        // line 43
        echo "    ";
        $this->displayBlock('body', $context, $blocks);
        // line 44
        echo "    ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 48
        echo "</body>
";
        // line 49
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "</html>
";
        
        $__internal_d67202221790f8c0fad0e1e68f0f56517c46d431c81d0791a7d1793ceb973c00->leave($__internal_d67202221790f8c0fad0e1e68f0f56517c46d431c81d0791a7d1793ceb973c00_prof);

        
        $__internal_a1e90e252628d75c3292cc999a168c68539ea2eae5ee24a90d486a5511f2fa12->leave($__internal_a1e90e252628d75c3292cc999a168c68539ea2eae5ee24a90d486a5511f2fa12_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_433f93720b9257e9f8d2d952cb6169e601eba742aab0a7d2bc577a9beff45c1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_433f93720b9257e9f8d2d952cb6169e601eba742aab0a7d2bc577a9beff45c1d->enter($__internal_433f93720b9257e9f8d2d952cb6169e601eba742aab0a7d2bc577a9beff45c1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_908b0b8ce44cad3eb3a846e3c3f6af50377dbc84cb1bb9ba147f89d391ca67e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_908b0b8ce44cad3eb3a846e3c3f6af50377dbc84cb1bb9ba147f89d391ca67e0->enter($__internal_908b0b8ce44cad3eb3a846e3c3f6af50377dbc84cb1bb9ba147f89d391ca67e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_908b0b8ce44cad3eb3a846e3c3f6af50377dbc84cb1bb9ba147f89d391ca67e0->leave($__internal_908b0b8ce44cad3eb3a846e3c3f6af50377dbc84cb1bb9ba147f89d391ca67e0_prof);

        
        $__internal_433f93720b9257e9f8d2d952cb6169e601eba742aab0a7d2bc577a9beff45c1d->leave($__internal_433f93720b9257e9f8d2d952cb6169e601eba742aab0a7d2bc577a9beff45c1d_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_34692adbb4ad8300bde5d8576c08f154e31d8b7a00d8d6d0e5289c681f814c91 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34692adbb4ad8300bde5d8576c08f154e31d8b7a00d8d6d0e5289c681f814c91->enter($__internal_34692adbb4ad8300bde5d8576c08f154e31d8b7a00d8d6d0e5289c681f814c91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_a4dd412cc5b8235a4fc0d8193429f283cbe434396c09a1c606a1b305afb4bdc6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4dd412cc5b8235a4fc0d8193429f283cbe434396c09a1c606a1b305afb4bdc6->enter($__internal_a4dd412cc5b8235a4fc0d8193429f283cbe434396c09a1c606a1b305afb4bdc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            <link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\"/>
        ";
        
        $__internal_a4dd412cc5b8235a4fc0d8193429f283cbe434396c09a1c606a1b305afb4bdc6->leave($__internal_a4dd412cc5b8235a4fc0d8193429f283cbe434396c09a1c606a1b305afb4bdc6_prof);

        
        $__internal_34692adbb4ad8300bde5d8576c08f154e31d8b7a00d8d6d0e5289c681f814c91->leave($__internal_34692adbb4ad8300bde5d8576c08f154e31d8b7a00d8d6d0e5289c681f814c91_prof);

    }

    // line 13
    public function block_nav($context, array $blocks = array())
    {
        $__internal_a222d0865d1b04b80e12bb06401fade970c75c614ae5568b570a448ac2761e97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a222d0865d1b04b80e12bb06401fade970c75c614ae5568b570a448ac2761e97->enter($__internal_a222d0865d1b04b80e12bb06401fade970c75c614ae5568b570a448ac2761e97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "nav"));

        $__internal_45abb2ecc026df66bd23a9d927f4679add9247fcda8b4ed1915e7a703f921dc0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45abb2ecc026df66bd23a9d927f4679add9247fcda8b4ed1915e7a703f921dc0->enter($__internal_45abb2ecc026df66bd23a9d927f4679add9247fcda8b4ed1915e7a703f921dc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "nav"));

        // line 14
        echo "            <nav class=\"navbar navbar-default text-uppercase\" style=\"background-color: #e1e1e1;\">
                <div class=\"container\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#main-menu\" aria-expanded=\"false\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <a class=\"navbar-brand\" href=\"#\">
                            <img src=\"img/logo.png\" alt=\"WEB SCHOOL\" class=\"img-responsive\">
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class=\"collapse navbar-collapse\" id=\"main-menu\">
                        <ul class=\"nav navbar-nav navbar-right text-center\">
                            <li><a class=\"active\" href=\"#\">home</a></li>
                            <li><a href=\"#\">about</a></li>
                            <li><a href=\"#\">services</a></li>
                            <li><a href=\"#\">portfolio</a></li>
                            <li><a href=\"#\">tim</a></li>
                            <li><a href=\"#\">blog</a></li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container-fluid -->
            </nav>
        ";
        
        $__internal_45abb2ecc026df66bd23a9d927f4679add9247fcda8b4ed1915e7a703f921dc0->leave($__internal_45abb2ecc026df66bd23a9d927f4679add9247fcda8b4ed1915e7a703f921dc0_prof);

        
        $__internal_a222d0865d1b04b80e12bb06401fade970c75c614ae5568b570a448ac2761e97->leave($__internal_a222d0865d1b04b80e12bb06401fade970c75c614ae5568b570a448ac2761e97_prof);

    }

    // line 43
    public function block_body($context, array $blocks = array())
    {
        $__internal_a0362d4b287d60905223949b78bc3412846d9b00734d8a5f23045a54ab783036 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0362d4b287d60905223949b78bc3412846d9b00734d8a5f23045a54ab783036->enter($__internal_a0362d4b287d60905223949b78bc3412846d9b00734d8a5f23045a54ab783036_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_36685f54335d1d42bff2d0399a0e3e63aa3babaafebcd2074d7279e8a88f1b40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36685f54335d1d42bff2d0399a0e3e63aa3babaafebcd2074d7279e8a88f1b40->enter($__internal_36685f54335d1d42bff2d0399a0e3e63aa3babaafebcd2074d7279e8a88f1b40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_36685f54335d1d42bff2d0399a0e3e63aa3babaafebcd2074d7279e8a88f1b40->leave($__internal_36685f54335d1d42bff2d0399a0e3e63aa3babaafebcd2074d7279e8a88f1b40_prof);

        
        $__internal_a0362d4b287d60905223949b78bc3412846d9b00734d8a5f23045a54ab783036->leave($__internal_a0362d4b287d60905223949b78bc3412846d9b00734d8a5f23045a54ab783036_prof);

    }

    // line 44
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_ec707652a48a1287f233e9d93bbbb0e4327144d594ec5616af77c7b6d6e55632 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec707652a48a1287f233e9d93bbbb0e4327144d594ec5616af77c7b6d6e55632->enter($__internal_ec707652a48a1287f233e9d93bbbb0e4327144d594ec5616af77c7b6d6e55632_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_0e0c4775ed56b880617c5e437d9ac97a4cce3fb30780c9ddf8bbca8ff9399fde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e0c4775ed56b880617c5e437d9ac97a4cce3fb30780c9ddf8bbca8ff9399fde->enter($__internal_0e0c4775ed56b880617c5e437d9ac97a4cce3fb30780c9ddf8bbca8ff9399fde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 45
        echo "        <script src=\"../../../web/js/main.js\" type=\"text/javascript\"></script>
        <link href=\"../../../web/css/bootstrap.min.css\" rel=\"stylesheet\" type=\"text/css\"/>
    ";
        
        $__internal_0e0c4775ed56b880617c5e437d9ac97a4cce3fb30780c9ddf8bbca8ff9399fde->leave($__internal_0e0c4775ed56b880617c5e437d9ac97a4cce3fb30780c9ddf8bbca8ff9399fde_prof);

        
        $__internal_ec707652a48a1287f233e9d93bbbb0e4327144d594ec5616af77c7b6d6e55632->leave($__internal_ec707652a48a1287f233e9d93bbbb0e4327144d594ec5616af77c7b6d6e55632_prof);

    }

    // line 49
    public function block_footer($context, array $blocks = array())
    {
        $__internal_684c8cc7452a66293121c7bfcd034bb369f7143ef6b1f3c52745375c6f4678a8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_684c8cc7452a66293121c7bfcd034bb369f7143ef6b1f3c52745375c6f4678a8->enter($__internal_684c8cc7452a66293121c7bfcd034bb369f7143ef6b1f3c52745375c6f4678a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_9d4dea61e1e1766146fdc90cb8d8f6fa23e292645e92c54a37add4620c7ae8bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d4dea61e1e1766146fdc90cb8d8f6fa23e292645e92c54a37add4620c7ae8bd->enter($__internal_9d4dea61e1e1766146fdc90cb8d8f6fa23e292645e92c54a37add4620c7ae8bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 50
        echo "    <footer>
    <div class=\"container\">
        <p> Copyright &copy; Cubes School , Backend Course</p>
        <a href=\"#top\"><span class=\"fa fa-chevron-circle-up\"></span></a>
    </div>
    </footer>
";
        
        $__internal_9d4dea61e1e1766146fdc90cb8d8f6fa23e292645e92c54a37add4620c7ae8bd->leave($__internal_9d4dea61e1e1766146fdc90cb8d8f6fa23e292645e92c54a37add4620c7ae8bd_prof);

        
        $__internal_684c8cc7452a66293121c7bfcd034bb369f7143ef6b1f3c52745375c6f4678a8->leave($__internal_684c8cc7452a66293121c7bfcd034bb369f7143ef6b1f3c52745375c6f4678a8_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  208 => 50,  199 => 49,  187 => 45,  178 => 44,  161 => 43,  123 => 14,  114 => 13,  103 => 7,  94 => 6,  76 => 5,  65 => 57,  63 => 49,  60 => 48,  57 => 44,  54 => 43,  52 => 13,  46 => 10,  43 => 9,  41 => 6,  37 => 5,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}
            <link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\"/>
        {% endblock %}

        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block nav %}
            <nav class=\"navbar navbar-default text-uppercase\" style=\"background-color: #e1e1e1;\">
                <div class=\"container\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#main-menu\" aria-expanded=\"false\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <a class=\"navbar-brand\" href=\"#\">
                            <img src=\"img/logo.png\" alt=\"WEB SCHOOL\" class=\"img-responsive\">
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class=\"collapse navbar-collapse\" id=\"main-menu\">
                        <ul class=\"nav navbar-nav navbar-right text-center\">
                            <li><a class=\"active\" href=\"#\">home</a></li>
                            <li><a href=\"#\">about</a></li>
                            <li><a href=\"#\">services</a></li>
                            <li><a href=\"#\">portfolio</a></li>
                            <li><a href=\"#\">tim</a></li>
                            <li><a href=\"#\">blog</a></li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container-fluid -->
            </nav>
        {% endblock %}
    {% block body %}{% endblock %}
    {% block javascripts %}
        <script src=\"../../../web/js/main.js\" type=\"text/javascript\"></script>
        <link href=\"../../../web/css/bootstrap.min.css\" rel=\"stylesheet\" type=\"text/css\"/>
    {% endblock %}
</body>
{% block footer %}
    <footer>
    <div class=\"container\">
        <p> Copyright &copy; Cubes School , Backend Course</p>
        <a href=\"#top\"><span class=\"fa fa-chevron-circle-up\"></span></a>
    </div>
    </footer>
{% endblock %}
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\symShop\\app\\Resources\\views\\base.html.twig");
    }
}
