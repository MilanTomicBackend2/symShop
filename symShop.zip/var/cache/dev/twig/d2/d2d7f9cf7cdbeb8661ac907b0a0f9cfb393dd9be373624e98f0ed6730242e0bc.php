<?php

/* product/list.html.twig */
class __TwigTemplate_07cd421c8caaace4d726a3625bad68d55f4cf6b1c7118e1d0375285291d87eca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "product/list.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_adf2abb218157526cf98865c0ef5a44a83df1ae1529d50b071471d05a4719063 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_adf2abb218157526cf98865c0ef5a44a83df1ae1529d50b071471d05a4719063->enter($__internal_adf2abb218157526cf98865c0ef5a44a83df1ae1529d50b071471d05a4719063_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/list.html.twig"));

        $__internal_fba9b6e6b90d637369c03e59ac583a9b7ab3f9158c7beb01cba89e02dffeb50e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fba9b6e6b90d637369c03e59ac583a9b7ab3f9158c7beb01cba89e02dffeb50e->enter($__internal_fba9b6e6b90d637369c03e59ac583a9b7ab3f9158c7beb01cba89e02dffeb50e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_adf2abb218157526cf98865c0ef5a44a83df1ae1529d50b071471d05a4719063->leave($__internal_adf2abb218157526cf98865c0ef5a44a83df1ae1529d50b071471d05a4719063_prof);

        
        $__internal_fba9b6e6b90d637369c03e59ac583a9b7ab3f9158c7beb01cba89e02dffeb50e->leave($__internal_fba9b6e6b90d637369c03e59ac583a9b7ab3f9158c7beb01cba89e02dffeb50e_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_997b0c4ce90b3a6abc1d22a2194a00cfa0f1733279b1742e5d28263174922a6b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_997b0c4ce90b3a6abc1d22a2194a00cfa0f1733279b1742e5d28263174922a6b->enter($__internal_997b0c4ce90b3a6abc1d22a2194a00cfa0f1733279b1742e5d28263174922a6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b4432096fc24c505c6cc68ce103ed064356efcf56f3e1397e2ddd27be7296063 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b4432096fc24c505c6cc68ce103ed064356efcf56f3e1397e2ddd27be7296063->enter($__internal_b4432096fc24c505c6cc68ce103ed064356efcf56f3e1397e2ddd27be7296063_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Lista proizvoda";
        
        $__internal_b4432096fc24c505c6cc68ce103ed064356efcf56f3e1397e2ddd27be7296063->leave($__internal_b4432096fc24c505c6cc68ce103ed064356efcf56f3e1397e2ddd27be7296063_prof);

        
        $__internal_997b0c4ce90b3a6abc1d22a2194a00cfa0f1733279b1742e5d28263174922a6b->leave($__internal_997b0c4ce90b3a6abc1d22a2194a00cfa0f1733279b1742e5d28263174922a6b_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d61dc12c92eabc2e069b89e987acf320a32dc10a576d33f6c024144c1b3c358d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d61dc12c92eabc2e069b89e987acf320a32dc10a576d33f6c024144c1b3c358d->enter($__internal_d61dc12c92eabc2e069b89e987acf320a32dc10a576d33f6c024144c1b3c358d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_44d94e7ee78097fabda6c2906102890e1c96a4a9821284455a82cbdc60920ba3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44d94e7ee78097fabda6c2906102890e1c96a4a9821284455a82cbdc60920ba3->enter($__internal_44d94e7ee78097fabda6c2906102890e1c96a4a9821284455a82cbdc60920ba3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>    
";
        
        $__internal_44d94e7ee78097fabda6c2906102890e1c96a4a9821284455a82cbdc60920ba3->leave($__internal_44d94e7ee78097fabda6c2906102890e1c96a4a9821284455a82cbdc60920ba3_prof);

        
        $__internal_d61dc12c92eabc2e069b89e987acf320a32dc10a576d33f6c024144c1b3c358d->leave($__internal_d61dc12c92eabc2e069b89e987acf320a32dc10a576d33f6c024144c1b3c358d_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_d3b31a83cdaaad87ed40dde16fa88a578b6ecd268597eced144add8f24a898d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3b31a83cdaaad87ed40dde16fa88a578b6ecd268597eced144add8f24a898d9->enter($__internal_d3b31a83cdaaad87ed40dde16fa88a578b6ecd268597eced144add8f24a898d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_12f6745ce46fe892dac9ba061980aa5a63fbde12dd185784c2a6ac82f894e80e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12f6745ce46fe892dac9ba061980aa5a63fbde12dd185784c2a6ac82f894e80e->enter($__internal_12f6745ce46fe892dac9ba061980aa5a63fbde12dd185784c2a6ac82f894e80e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
    <section class=\"product-wrapper\">
        <h2>Proizvodi</h2>
        <div class=\"row\">
            ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) ? $context["products"] : $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            echo "   
                <!-- Ovo je sve jedan proizvod -->
                <div class=\"col-sm-6 col-md-4 col-lg-3\">
                    <article class=\"product\">
                        <span class=\"sticker\">
                            <img src=\"\" alt=\"\"/>
                        </span>
                        <figure>
                            <img src=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/slika.jpg")), "html", null, true);
            echo "\" alt=\"Symfony!\" />
                            
                        </figure>
                        <p class=\"product-title\">";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array()), "html", null, true);
            echo "</p>
                        <div class=\"product-price\">
                            <p class=\"price \">Cena: <span>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "price", array()), "html", null, true);
            echo "</span></p>
                            <p class=\"discount-price\">Opis: <span>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "description", array()), "html", null, true);
            echo "</span></p>
                        </div>
                        <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("product_show", array("name" => $this->getAttribute($context["product"], "title", array()))), "html", null, true);
            echo "\" class=\"more\">Detail</a>
                    </article>
                </div><!--Kraj proizvoda-->
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "    </section>
    ";
        // line 49
        echo "


";
        
        $__internal_12f6745ce46fe892dac9ba061980aa5a63fbde12dd185784c2a6ac82f894e80e->leave($__internal_12f6745ce46fe892dac9ba061980aa5a63fbde12dd185784c2a6ac82f894e80e_prof);

        
        $__internal_d3b31a83cdaaad87ed40dde16fa88a578b6ecd268597eced144add8f24a898d9->leave($__internal_d3b31a83cdaaad87ed40dde16fa88a578b6ecd268597eced144add8f24a898d9_prof);

    }

    // line 54
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e5fe8a60a2f877a6f7f7a97f7d1170598521d98c1d4e2fda10687f168afee61f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5fe8a60a2f877a6f7f7a97f7d1170598521d98c1d4e2fda10687f168afee61f->enter($__internal_e5fe8a60a2f877a6f7f7a97f7d1170598521d98c1d4e2fda10687f168afee61f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_cd8138fdab1838e481b0c920ed1ce0d110a720f58aafc526b9c3d5662a9c6724 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd8138fdab1838e481b0c920ed1ce0d110a720f58aafc526b9c3d5662a9c6724->enter($__internal_cd8138fdab1838e481b0c920ed1ce0d110a720f58aafc526b9c3d5662a9c6724_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 55
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/main.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
    <link href=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
";
        
        $__internal_cd8138fdab1838e481b0c920ed1ce0d110a720f58aafc526b9c3d5662a9c6724->leave($__internal_cd8138fdab1838e481b0c920ed1ce0d110a720f58aafc526b9c3d5662a9c6724_prof);

        
        $__internal_e5fe8a60a2f877a6f7f7a97f7d1170598521d98c1d4e2fda10687f168afee61f->leave($__internal_e5fe8a60a2f877a6f7f7a97f7d1170598521d98c1d4e2fda10687f168afee61f_prof);

    }

    public function getTemplateName()
    {
        return "product/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 56,  166 => 55,  157 => 54,  144 => 49,  141 => 34,  131 => 30,  126 => 28,  122 => 27,  117 => 25,  111 => 22,  98 => 14,  92 => 10,  83 => 9,  70 => 6,  61 => 5,  43 => 3,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}
{% block title %}Lista proizvoda{% endblock %}

{% block stylesheets %}
    <link href=\"{{ asset('css/style.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>    
{% endblock %}

{% block body %}

    <section class=\"product-wrapper\">
        <h2>Proizvodi</h2>
        <div class=\"row\">
            {% for product in products %}   
                <!-- Ovo je sve jedan proizvod -->
                <div class=\"col-sm-6 col-md-4 col-lg-3\">
                    <article class=\"product\">
                        <span class=\"sticker\">
                            <img src=\"\" alt=\"\"/>
                        </span>
                        <figure>
                            <img src=\"{{ absolute_url(asset('img/slika.jpg')) }}\" alt=\"Symfony!\" />
                            
                        </figure>
                        <p class=\"product-title\">{{product.title}}</p>
                        <div class=\"product-price\">
                            <p class=\"price \">Cena: <span>{{ product.price }}</span></p>
                            <p class=\"discount-price\">Opis: <span>{{ product.description }}</span></p>
                        </div>
                        <a href=\"{{ path('product_show', { 'name' :  product.title }) }}\" class=\"more\">Detail</a>
                    </article>
                </div><!--Kraj proizvoda-->
            {% endfor %}
    </section>
    {#<section class=\"last-watched-products\">
        <h2>Pregledani proizvodi</h2>
        <div class=\"row\">
            <div class=\"col-xs-6 col-sm-3 col-lg-2\">
                <article class=\"product\">

                    <figure>
                        <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                    </figure>
                    <p class=\"product-title\">Sushi</p>
                    <a href=\"#\" class=\"more\">Detail</a>
                </article>
            </div>
    </section>#}



{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/main.js')}}\" type=\"text/javascript\"></script>
    <link href=\"{{asset('css/bootstrap.min.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>
{% endblock %}", "product/list.html.twig", "C:\\xampp\\htdocs\\symShop\\app\\Resources\\views\\product\\list.html.twig");
    }
}
