<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_e6c32123bc7dccf9b089e4f06070d22e869b418a2b59d2d47d58ebfff8f41661 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6ea5281b1c0330bacf16922cb1123f8312e92d1a3770593acd8e9c2494cb1bc4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ea5281b1c0330bacf16922cb1123f8312e92d1a3770593acd8e9c2494cb1bc4->enter($__internal_6ea5281b1c0330bacf16922cb1123f8312e92d1a3770593acd8e9c2494cb1bc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_961766e6bfcf5078663e531c6090f3416c2dbfa1c6efd91409bbcbe66e17160f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_961766e6bfcf5078663e531c6090f3416c2dbfa1c6efd91409bbcbe66e17160f->enter($__internal_961766e6bfcf5078663e531c6090f3416c2dbfa1c6efd91409bbcbe66e17160f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6ea5281b1c0330bacf16922cb1123f8312e92d1a3770593acd8e9c2494cb1bc4->leave($__internal_6ea5281b1c0330bacf16922cb1123f8312e92d1a3770593acd8e9c2494cb1bc4_prof);

        
        $__internal_961766e6bfcf5078663e531c6090f3416c2dbfa1c6efd91409bbcbe66e17160f->leave($__internal_961766e6bfcf5078663e531c6090f3416c2dbfa1c6efd91409bbcbe66e17160f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_86eafdc9dec8ca3b64aaef561d3082be958432f81943985a847f2b2d8fb7cf92 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_86eafdc9dec8ca3b64aaef561d3082be958432f81943985a847f2b2d8fb7cf92->enter($__internal_86eafdc9dec8ca3b64aaef561d3082be958432f81943985a847f2b2d8fb7cf92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_9659677b1d28c0b6703f0b4d3509c5e1e95808d6a36662fc9243f960e5e81782 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9659677b1d28c0b6703f0b4d3509c5e1e95808d6a36662fc9243f960e5e81782->enter($__internal_9659677b1d28c0b6703f0b4d3509c5e1e95808d6a36662fc9243f960e5e81782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_9659677b1d28c0b6703f0b4d3509c5e1e95808d6a36662fc9243f960e5e81782->leave($__internal_9659677b1d28c0b6703f0b4d3509c5e1e95808d6a36662fc9243f960e5e81782_prof);

        
        $__internal_86eafdc9dec8ca3b64aaef561d3082be958432f81943985a847f2b2d8fb7cf92->leave($__internal_86eafdc9dec8ca3b64aaef561d3082be958432f81943985a847f2b2d8fb7cf92_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e6043fcd70abf26cc11cc370e2e5abea39e99c7d881e35cbd65666267bc7e39f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e6043fcd70abf26cc11cc370e2e5abea39e99c7d881e35cbd65666267bc7e39f->enter($__internal_e6043fcd70abf26cc11cc370e2e5abea39e99c7d881e35cbd65666267bc7e39f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_7fab00aa1070465fee6d8ef5041008a780da45d49f6ff6e45e8cad692f90a59f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7fab00aa1070465fee6d8ef5041008a780da45d49f6ff6e45e8cad692f90a59f->enter($__internal_7fab00aa1070465fee6d8ef5041008a780da45d49f6ff6e45e8cad692f90a59f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_7fab00aa1070465fee6d8ef5041008a780da45d49f6ff6e45e8cad692f90a59f->leave($__internal_7fab00aa1070465fee6d8ef5041008a780da45d49f6ff6e45e8cad692f90a59f_prof);

        
        $__internal_e6043fcd70abf26cc11cc370e2e5abea39e99c7d881e35cbd65666267bc7e39f->leave($__internal_e6043fcd70abf26cc11cc370e2e5abea39e99c7d881e35cbd65666267bc7e39f_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_cd47b81cead507f6ce36c68f26b7c09ec41ce9e8b6d66e2ddece82ecd8c6ac55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cd47b81cead507f6ce36c68f26b7c09ec41ce9e8b6d66e2ddece82ecd8c6ac55->enter($__internal_cd47b81cead507f6ce36c68f26b7c09ec41ce9e8b6d66e2ddece82ecd8c6ac55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_8b9de6d737b19a2d96850f61b065f0040f6e1736cf147304c38db7163f73e9c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b9de6d737b19a2d96850f61b065f0040f6e1736cf147304c38db7163f73e9c6->enter($__internal_8b9de6d737b19a2d96850f61b065f0040f6e1736cf147304c38db7163f73e9c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_8b9de6d737b19a2d96850f61b065f0040f6e1736cf147304c38db7163f73e9c6->leave($__internal_8b9de6d737b19a2d96850f61b065f0040f6e1736cf147304c38db7163f73e9c6_prof);

        
        $__internal_cd47b81cead507f6ce36c68f26b7c09ec41ce9e8b6d66e2ddece82ecd8c6ac55->leave($__internal_cd47b81cead507f6ce36c68f26b7c09ec41ce9e8b6d66e2ddece82ecd8c6ac55_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\symShop\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
