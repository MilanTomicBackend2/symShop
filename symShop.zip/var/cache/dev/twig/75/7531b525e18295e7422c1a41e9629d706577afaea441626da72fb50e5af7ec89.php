<?php

/* product/homepage.html.twig */
class __TwigTemplate_522c8de18e14106c94c70f537719cadcad2e5b4f5a2c3ada2fcff4ec59ff086b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "product/homepage.html.twig", 2);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76197ad51fe2477b129cda4381ead1fb1fa72e73a23bcb121ee5af3ea16bb3aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76197ad51fe2477b129cda4381ead1fb1fa72e73a23bcb121ee5af3ea16bb3aa->enter($__internal_76197ad51fe2477b129cda4381ead1fb1fa72e73a23bcb121ee5af3ea16bb3aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/homepage.html.twig"));

        $__internal_7309c2754ced19ed6a7fc28589e2e5999dee54b90466fc8200cc26025d344574 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7309c2754ced19ed6a7fc28589e2e5999dee54b90466fc8200cc26025d344574->enter($__internal_7309c2754ced19ed6a7fc28589e2e5999dee54b90466fc8200cc26025d344574_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_76197ad51fe2477b129cda4381ead1fb1fa72e73a23bcb121ee5af3ea16bb3aa->leave($__internal_76197ad51fe2477b129cda4381ead1fb1fa72e73a23bcb121ee5af3ea16bb3aa_prof);

        
        $__internal_7309c2754ced19ed6a7fc28589e2e5999dee54b90466fc8200cc26025d344574->leave($__internal_7309c2754ced19ed6a7fc28589e2e5999dee54b90466fc8200cc26025d344574_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_cbdb435928e75c8c16ebdfe3de2ca1dbe0dbb38578d7f7a133dd7c64302bc191 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cbdb435928e75c8c16ebdfe3de2ca1dbe0dbb38578d7f7a133dd7c64302bc191->enter($__internal_cbdb435928e75c8c16ebdfe3de2ca1dbe0dbb38578d7f7a133dd7c64302bc191_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_07e4a1e446e367ce4c2b9c1ea519a6101da3b48e102141427745f0d8e74ec050 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07e4a1e446e367ce4c2b9c1ea519a6101da3b48e102141427745f0d8e74ec050->enter($__internal_07e4a1e446e367ce4c2b9c1ea519a6101da3b48e102141427745f0d8e74ec050_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" />    
";
        
        $__internal_07e4a1e446e367ce4c2b9c1ea519a6101da3b48e102141427745f0d8e74ec050->leave($__internal_07e4a1e446e367ce4c2b9c1ea519a6101da3b48e102141427745f0d8e74ec050_prof);

        
        $__internal_cbdb435928e75c8c16ebdfe3de2ca1dbe0dbb38578d7f7a133dd7c64302bc191->leave($__internal_cbdb435928e75c8c16ebdfe3de2ca1dbe0dbb38578d7f7a133dd7c64302bc191_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_bfedd525a2ed7e49c66b32f34c00f3514f63416873d2c68b5a1c6d6c7d334b64 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bfedd525a2ed7e49c66b32f34c00f3514f63416873d2c68b5a1c6d6c7d334b64->enter($__internal_bfedd525a2ed7e49c66b32f34c00f3514f63416873d2c68b5a1c6d6c7d334b64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e2c259d08bc87b4f6605517c1303db37b8e06eec3e6ba4df43885009e1c480f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2c259d08bc87b4f6605517c1303db37b8e06eec3e6ba4df43885009e1c480f1->enter($__internal_e2c259d08bc87b4f6605517c1303db37b8e06eec3e6ba4df43885009e1c480f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Homepage";
        
        $__internal_e2c259d08bc87b4f6605517c1303db37b8e06eec3e6ba4df43885009e1c480f1->leave($__internal_e2c259d08bc87b4f6605517c1303db37b8e06eec3e6ba4df43885009e1c480f1_prof);

        
        $__internal_bfedd525a2ed7e49c66b32f34c00f3514f63416873d2c68b5a1c6d6c7d334b64->leave($__internal_bfedd525a2ed7e49c66b32f34c00f3514f63416873d2c68b5a1c6d6c7d334b64_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_c1397c0818f4987344bb44c9e0cf6a098041aa1481bebfc7aa47f4487b6578fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c1397c0818f4987344bb44c9e0cf6a098041aa1481bebfc7aa47f4487b6578fd->enter($__internal_c1397c0818f4987344bb44c9e0cf6a098041aa1481bebfc7aa47f4487b6578fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_949f042ecf6b963f4126635cb78c99893b7aa1651ca532afc4f1143b34dec49f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_949f042ecf6b963f4126635cb78c99893b7aa1651ca532afc4f1143b34dec49f->enter($__internal_949f042ecf6b963f4126635cb78c99893b7aa1651ca532afc4f1143b34dec49f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "


    <section class=\"product-wrapper\">
        <h2>Naslovna strana</h2>
        <div class=\"row\">
            ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["homepage"]) ? $context["homepage"] : $this->getContext($context, "homepage")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 18
            echo "
                ";
            // line 19
            if (($this->getAttribute($context["product"], "price", array()) < 19)) {
                // line 20
                echo "                    <!-- Ovo je sve jedan proizvod -->
                    <div class=\"col-sm-6 col-md-4 col-lg-3\">
                        <article class=\"product\">
                            <span class=\"sticker\">
                                <img src=\"\" alt=\"\"/>
                            </span>
                            <figure>
                                <img src=\"";
                // line 27
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/slika.jpg")), "html", null, true);
                echo "\" alt=\"\"/>
                            </figure>
                            <p class=\"product-title\">";
                // line 29
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array()), "html", null, true);
                echo "</p>
                            <div class=\"product-price\">
                                <p class=\"price \">Cena: <span>";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "price", array()), "html", null, true);
                echo "</span></p>
                                <p class=\"discount-price\">Opis: <span>";
                // line 32
                echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "description", array()), "html", null, true);
                echo "</span></p>
                            </div>
                            <a href=\"";
                // line 34
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("product_show", array("name" => $this->getAttribute($context["product"], "title", array()))), "html", null, true);
                echo "\" class=\"more\">Detail</a>
                        </article>
                    </div><!--Kraj proizvoda-->
                ";
            }
            // line 37
            echo "  

            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "    </section>



";
        
        $__internal_949f042ecf6b963f4126635cb78c99893b7aa1651ca532afc4f1143b34dec49f->leave($__internal_949f042ecf6b963f4126635cb78c99893b7aa1651ca532afc4f1143b34dec49f_prof);

        
        $__internal_c1397c0818f4987344bb44c9e0cf6a098041aa1481bebfc7aa47f4487b6578fd->leave($__internal_c1397c0818f4987344bb44c9e0cf6a098041aa1481bebfc7aa47f4487b6578fd_prof);

    }

    // line 45
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_05293809a9813e716fd3236ec8db99a0a337a17c94b3e4d001113670eea18e2b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_05293809a9813e716fd3236ec8db99a0a337a17c94b3e4d001113670eea18e2b->enter($__internal_05293809a9813e716fd3236ec8db99a0a337a17c94b3e4d001113670eea18e2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_7aa0c835a314cb999f6b3006610ecf25dccf2dfc3f7a581a5755ed5baba4f965 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7aa0c835a314cb999f6b3006610ecf25dccf2dfc3f7a581a5755ed5baba4f965->enter($__internal_7aa0c835a314cb999f6b3006610ecf25dccf2dfc3f7a581a5755ed5baba4f965_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 46
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/main.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
    <link href=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
";
        
        $__internal_7aa0c835a314cb999f6b3006610ecf25dccf2dfc3f7a581a5755ed5baba4f965->leave($__internal_7aa0c835a314cb999f6b3006610ecf25dccf2dfc3f7a581a5755ed5baba4f965_prof);

        
        $__internal_05293809a9813e716fd3236ec8db99a0a337a17c94b3e4d001113670eea18e2b->leave($__internal_05293809a9813e716fd3236ec8db99a0a337a17c94b3e4d001113670eea18e2b_prof);

    }

    public function getTemplateName()
    {
        return "product/homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  180 => 47,  175 => 46,  166 => 45,  152 => 40,  144 => 37,  137 => 34,  132 => 32,  128 => 31,  123 => 29,  118 => 27,  109 => 20,  107 => 19,  104 => 18,  100 => 17,  92 => 11,  83 => 10,  65 => 8,  52 => 5,  43 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}

{% block stylesheets %}
    <link href=\"{{ asset('css/style.css')}}\" rel=\"stylesheet\" type=\"text/css\" />    
{% endblock %}

{% block title %}Homepage{% endblock %}

{% block body %}



    <section class=\"product-wrapper\">
        <h2>Naslovna strana</h2>
        <div class=\"row\">
            {% for product in homepage %}

                {% if product.price < 19 %}
                    <!-- Ovo je sve jedan proizvod -->
                    <div class=\"col-sm-6 col-md-4 col-lg-3\">
                        <article class=\"product\">
                            <span class=\"sticker\">
                                <img src=\"\" alt=\"\"/>
                            </span>
                            <figure>
                                <img src=\"{{ absolute_url(asset('img/slika.jpg')) }}\" alt=\"\"/>
                            </figure>
                            <p class=\"product-title\">{{ product.title }}</p>
                            <div class=\"product-price\">
                                <p class=\"price \">Cena: <span>{{ product.price }}</span></p>
                                <p class=\"discount-price\">Opis: <span>{{ product.description }}</span></p>
                            </div>
                            <a href=\"{{ path('product_show', { 'name' :  product.title }) }}\" class=\"more\">Detail</a>
                        </article>
                    </div><!--Kraj proizvoda-->
                {% endif %}  

            {% endfor %}
    </section>



{% endblock %}
{% block javascripts %}
    <script src=\"{{ asset('js/main.js')}}\" type=\"text/javascript\"></script>
    <link href=\"{{asset('css/bootstrap.min.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>
{% endblock %}


", "product/homepage.html.twig", "C:\\xampp\\htdocs\\symShop\\app\\Resources\\views\\product\\homepage.html.twig");
    }
}
