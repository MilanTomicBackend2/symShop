<?php

/* product/list.html.twig */
class __TwigTemplate_07cd421c8caaace4d726a3625bad68d55f4cf6b1c7118e1d0375285291d87eca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "product/list.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_57a0a16b2bc30f161232d22a720c8ccca4ff6755eb3b7aa3ad907ba9dd64eb7c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_57a0a16b2bc30f161232d22a720c8ccca4ff6755eb3b7aa3ad907ba9dd64eb7c->enter($__internal_57a0a16b2bc30f161232d22a720c8ccca4ff6755eb3b7aa3ad907ba9dd64eb7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/list.html.twig"));

        $__internal_2d6ffc4c2609abdb92897c351e88e6df551a0141e42ca561ad8e45cef4bc42e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d6ffc4c2609abdb92897c351e88e6df551a0141e42ca561ad8e45cef4bc42e7->enter($__internal_2d6ffc4c2609abdb92897c351e88e6df551a0141e42ca561ad8e45cef4bc42e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_57a0a16b2bc30f161232d22a720c8ccca4ff6755eb3b7aa3ad907ba9dd64eb7c->leave($__internal_57a0a16b2bc30f161232d22a720c8ccca4ff6755eb3b7aa3ad907ba9dd64eb7c_prof);

        
        $__internal_2d6ffc4c2609abdb92897c351e88e6df551a0141e42ca561ad8e45cef4bc42e7->leave($__internal_2d6ffc4c2609abdb92897c351e88e6df551a0141e42ca561ad8e45cef4bc42e7_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_b01866e81585bb2052c6d1d3a3378a9d83645271dadd21bb91961d5a050dd8cc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b01866e81585bb2052c6d1d3a3378a9d83645271dadd21bb91961d5a050dd8cc->enter($__internal_b01866e81585bb2052c6d1d3a3378a9d83645271dadd21bb91961d5a050dd8cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_eb3903a7153688113161badeb209d47b14ba812df22806db5b10e5a3f7297c27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb3903a7153688113161badeb209d47b14ba812df22806db5b10e5a3f7297c27->enter($__internal_eb3903a7153688113161badeb209d47b14ba812df22806db5b10e5a3f7297c27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Lista proizvoda";
        
        $__internal_eb3903a7153688113161badeb209d47b14ba812df22806db5b10e5a3f7297c27->leave($__internal_eb3903a7153688113161badeb209d47b14ba812df22806db5b10e5a3f7297c27_prof);

        
        $__internal_b01866e81585bb2052c6d1d3a3378a9d83645271dadd21bb91961d5a050dd8cc->leave($__internal_b01866e81585bb2052c6d1d3a3378a9d83645271dadd21bb91961d5a050dd8cc_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_71554b646fefd8ee3f17c95e046c565f7050e33a7891162a4811d9e5874fbc79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_71554b646fefd8ee3f17c95e046c565f7050e33a7891162a4811d9e5874fbc79->enter($__internal_71554b646fefd8ee3f17c95e046c565f7050e33a7891162a4811d9e5874fbc79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_576c2befebf0d56dde0db59280eaff12e716563e8300be93f78c44d4af4da372 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_576c2befebf0d56dde0db59280eaff12e716563e8300be93f78c44d4af4da372->enter($__internal_576c2befebf0d56dde0db59280eaff12e716563e8300be93f78c44d4af4da372_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
";
        
        $__internal_576c2befebf0d56dde0db59280eaff12e716563e8300be93f78c44d4af4da372->leave($__internal_576c2befebf0d56dde0db59280eaff12e716563e8300be93f78c44d4af4da372_prof);

        
        $__internal_71554b646fefd8ee3f17c95e046c565f7050e33a7891162a4811d9e5874fbc79->leave($__internal_71554b646fefd8ee3f17c95e046c565f7050e33a7891162a4811d9e5874fbc79_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_6c9d515d1ecc5bbbd13a8e5ce3b4e620b0a9ad4fc55be02bbd608ae99fee7675 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c9d515d1ecc5bbbd13a8e5ce3b4e620b0a9ad4fc55be02bbd608ae99fee7675->enter($__internal_6c9d515d1ecc5bbbd13a8e5ce3b4e620b0a9ad4fc55be02bbd608ae99fee7675_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_2b51c15209c21fe999b3002c8c56fe4fdaae33c6080a5e7bea3c17f483ed7aad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b51c15209c21fe999b3002c8c56fe4fdaae33c6080a5e7bea3c17f483ed7aad->enter($__internal_2b51c15209c21fe999b3002c8c56fe4fdaae33c6080a5e7bea3c17f483ed7aad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Naziv</th>
                <th>Akcija</th>
            </tr>
        </thead>
        <tbody>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) ? $context["products"] : $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 21
            echo "                <tr>
                    <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "id", array(), "array"), "html", null, true);
            echo "</td>
                    <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array(), "array"), "html", null, true);
            echo "</td>
                    <td><a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("product_show", array("name" => $this->getAttribute($context["product"], "title", array(), "array"))), "html", null, true);
            echo "\">Detail</a></td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "        </tbody>
    </table>
    

";
        
        $__internal_2b51c15209c21fe999b3002c8c56fe4fdaae33c6080a5e7bea3c17f483ed7aad->leave($__internal_2b51c15209c21fe999b3002c8c56fe4fdaae33c6080a5e7bea3c17f483ed7aad_prof);

        
        $__internal_6c9d515d1ecc5bbbd13a8e5ce3b4e620b0a9ad4fc55be02bbd608ae99fee7675->leave($__internal_6c9d515d1ecc5bbbd13a8e5ce3b4e620b0a9ad4fc55be02bbd608ae99fee7675_prof);

    }

    public function getTemplateName()
    {
        return "product/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 27,  118 => 24,  114 => 23,  110 => 22,  107 => 21,  103 => 20,  91 => 10,  82 => 9,  69 => 6,  60 => 5,  42 => 3,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}
{% block title %}Lista proizvoda{% endblock %}

{% block stylesheets %}
    <link href=\"{{ asset('css/style.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>
{% endblock %}

{% block body %}
    
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Naziv</th>
                <th>Akcija</th>
            </tr>
        </thead>
        <tbody>
            {% for product in products %}
                <tr>
                    <td>{{ product['id'] }}</td>
                    <td>{{ product['title'] }}</td>
                    <td><a href=\"{{ path('product_show', { 'name' :  product['title'] }) }}\">Detail</a></td>
                </tr>
            {% endfor %}
        </tbody>
    </table>
    

{% endblock %}

{#{% block javascripts %}
    <script src=\"../js/main.js\" type=\"text/javascript\"></script>
{% endblock %}#}", "product/list.html.twig", "C:\\xampp\\htdocs\\symShop\\app\\Resources\\views\\product\\list.html.twig");
    }
}
