<?php

/* product/show.html.twig */
class __TwigTemplate_dcd68230ae06d4583ff935cdc1568e912b75c90f9dd93c6a38c02786bc016b8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "product/show.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c66db475dd49c1f57abdcee4deb9dd75fb73a5d5a7e6b675c32d88346b94385 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c66db475dd49c1f57abdcee4deb9dd75fb73a5d5a7e6b675c32d88346b94385->enter($__internal_4c66db475dd49c1f57abdcee4deb9dd75fb73a5d5a7e6b675c32d88346b94385_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/show.html.twig"));

        $__internal_ca40b50330af59388458584e0d29bc1feffad6a4dbf04799e79f0968b4c6b4b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca40b50330af59388458584e0d29bc1feffad6a4dbf04799e79f0968b4c6b4b4->enter($__internal_ca40b50330af59388458584e0d29bc1feffad6a4dbf04799e79f0968b4c6b4b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4c66db475dd49c1f57abdcee4deb9dd75fb73a5d5a7e6b675c32d88346b94385->leave($__internal_4c66db475dd49c1f57abdcee4deb9dd75fb73a5d5a7e6b675c32d88346b94385_prof);

        
        $__internal_ca40b50330af59388458584e0d29bc1feffad6a4dbf04799e79f0968b4c6b4b4->leave($__internal_ca40b50330af59388458584e0d29bc1feffad6a4dbf04799e79f0968b4c6b4b4_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_1212094833e334c0723ee99b864953a6b44cfa7ef98eaf7ef081f77bab63e6a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1212094833e334c0723ee99b864953a6b44cfa7ef98eaf7ef081f77bab63e6a7->enter($__internal_1212094833e334c0723ee99b864953a6b44cfa7ef98eaf7ef081f77bab63e6a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_88dfeace313fed602c7323169f02cdd5dd9f8987ec1f80255a4e998c670e5f79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88dfeace313fed602c7323169f02cdd5dd9f8987ec1f80255a4e998c670e5f79->enter($__internal_88dfeace313fed602c7323169f02cdd5dd9f8987ec1f80255a4e998c670e5f79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Detalji";
        
        $__internal_88dfeace313fed602c7323169f02cdd5dd9f8987ec1f80255a4e998c670e5f79->leave($__internal_88dfeace313fed602c7323169f02cdd5dd9f8987ec1f80255a4e998c670e5f79_prof);

        
        $__internal_1212094833e334c0723ee99b864953a6b44cfa7ef98eaf7ef081f77bab63e6a7->leave($__internal_1212094833e334c0723ee99b864953a6b44cfa7ef98eaf7ef081f77bab63e6a7_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e273b8f3dae54b261c8533e30bbc419b660d950af48b65c3569da6a59243827f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e273b8f3dae54b261c8533e30bbc419b660d950af48b65c3569da6a59243827f->enter($__internal_e273b8f3dae54b261c8533e30bbc419b660d950af48b65c3569da6a59243827f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_e191c53e76ca0075d62429bda86297504260814e0984b5dc7898fea7ff9084ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e191c53e76ca0075d62429bda86297504260814e0984b5dc7898fea7ff9084ae->enter($__internal_e191c53e76ca0075d62429bda86297504260814e0984b5dc7898fea7ff9084ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>    
";
        
        $__internal_e191c53e76ca0075d62429bda86297504260814e0984b5dc7898fea7ff9084ae->leave($__internal_e191c53e76ca0075d62429bda86297504260814e0984b5dc7898fea7ff9084ae_prof);

        
        $__internal_e273b8f3dae54b261c8533e30bbc419b660d950af48b65c3569da6a59243827f->leave($__internal_e273b8f3dae54b261c8533e30bbc419b660d950af48b65c3569da6a59243827f_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_3e0f0dd575985888fa23682656ac9ea8be865f8199db5b90499660d846dd318e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e0f0dd575985888fa23682656ac9ea8be865f8199db5b90499660d846dd318e->enter($__internal_3e0f0dd575985888fa23682656ac9ea8be865f8199db5b90499660d846dd318e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_401e284bea8b23d907a156cbe1a1b164e5383dcc1349a93b887a0697db2b64cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_401e284bea8b23d907a156cbe1a1b164e5383dcc1349a93b887a0697db2b64cc->enter($__internal_401e284bea8b23d907a156cbe1a1b164e5383dcc1349a93b887a0697db2b64cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    

    <main>
            <div class=\"container\">

                <div class=\"row\">
                    <!-- LEVI kontejner -->
                    <div class=\"col-md-9\">
                        <section class=\"single-product\">
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <article>
                                        <img class=\"img-responsive center-block\" src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/slika.jpg")), "html", null, true);
        echo "\" alt=\"\"/>
                                    </article>
                                </div>
                                <div class=\"col-sm-6\">
                                    <article>
                                        <p class=\"product-title\">";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["product"]) ? $context["product"] : $this->getContext($context, "product")), "title", array()), "html", null, true);
        echo "</p>
                                        <p class=\"price\">Cena: <span>";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["product"]) ? $context["product"] : $this->getContext($context, "product")), "price", array()), "html", null, true);
        echo "</span></p>
                                        <p class=\"discount-price\">Opis: <span>";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["product"]) ? $context["product"] : $this->getContext($context, "product")), "description", array()), "html", null, true);
        echo "</span></p>
                                    </article>
                                </div>
                            </div>

                        </section>


                        <section class=\"last-watched-products\">
                            <h2>Pregledani proizvodi</h2>
                            <div class=\"row\">
                                <div class=\"col-xs-6 col-sm-3 col-lg-2 \">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3 col-lg-2\">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3 col-lg-2 \">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3 col-lg-2\">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3 col-lg-2\">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3  col-lg-2 \">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                            </div>
                        </section>
                    </div><!-- kraj levog kontejnera-->


                    <!-- ASIDE -->
                    <div class=\"col-md-3 aside\">
                        <section class=\"contact \">
                            <h3>Adresa:</h3>
                            <p>Bulevar Mihaila Pupina 181</p>
                            <p>11000 Beograd</p>
                            <p class=\"phone\"><span class=\"fa fa-phone\"></span> 011/123-123</p>
                            <p class=\"email\"><span class=\"fa fa-envelope-o\"></span><a href=\"mailto:example@mail.com\">example@mail.com</a></p>
                            <p class=\"url\"><span class=\"fa fa-globe\"></span><a href=\"http://school.cubes.rs\">school.cubes.rs</a></p>
                        </section>
                    </div><!-- Kraj aside -->

                </div>
            </div>
        </main><!--main end-->
    
";
        
        $__internal_401e284bea8b23d907a156cbe1a1b164e5383dcc1349a93b887a0697db2b64cc->leave($__internal_401e284bea8b23d907a156cbe1a1b164e5383dcc1349a93b887a0697db2b64cc_prof);

        
        $__internal_3e0f0dd575985888fa23682656ac9ea8be865f8199db5b90499660d846dd318e->leave($__internal_3e0f0dd575985888fa23682656ac9ea8be865f8199db5b90499660d846dd318e_prof);

    }

    // line 116
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_29bebae9ce6480c9ffafb524d57904f26c8cb47cda14dc4f9d94cc87bc1502b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29bebae9ce6480c9ffafb524d57904f26c8cb47cda14dc4f9d94cc87bc1502b5->enter($__internal_29bebae9ce6480c9ffafb524d57904f26c8cb47cda14dc4f9d94cc87bc1502b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_3e3e68646facabe1b8dacff91ad8916321a9cf8a4c6a8de4ddd2f93639d6c0cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e3e68646facabe1b8dacff91ad8916321a9cf8a4c6a8de4ddd2f93639d6c0cc->enter($__internal_3e3e68646facabe1b8dacff91ad8916321a9cf8a4c6a8de4ddd2f93639d6c0cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 117
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/main.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
    <link href=\"";
        // line 118
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
";
        
        $__internal_3e3e68646facabe1b8dacff91ad8916321a9cf8a4c6a8de4ddd2f93639d6c0cc->leave($__internal_3e3e68646facabe1b8dacff91ad8916321a9cf8a4c6a8de4ddd2f93639d6c0cc_prof);

        
        $__internal_29bebae9ce6480c9ffafb524d57904f26c8cb47cda14dc4f9d94cc87bc1502b5->leave($__internal_29bebae9ce6480c9ffafb524d57904f26c8cb47cda14dc4f9d94cc87bc1502b5_prof);

    }

    public function getTemplateName()
    {
        return "product/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  233 => 118,  228 => 117,  219 => 116,  122 => 29,  118 => 28,  114 => 27,  106 => 22,  92 => 10,  83 => 9,  70 => 6,  61 => 5,  43 => 3,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}
{% block title %}Detalji{% endblock %}

{% block stylesheets %}
    <link href=\"{{ asset('css/style.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>    
{% endblock %}

{% block body %}
    

    <main>
            <div class=\"container\">

                <div class=\"row\">
                    <!-- LEVI kontejner -->
                    <div class=\"col-md-9\">
                        <section class=\"single-product\">
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <article>
                                        <img class=\"img-responsive center-block\" src=\"{{ absolute_url(asset('img/slika.jpg')) }}\" alt=\"\"/>
                                    </article>
                                </div>
                                <div class=\"col-sm-6\">
                                    <article>
                                        <p class=\"product-title\">{{ product.title }}</p>
                                        <p class=\"price\">Cena: <span>{{ product.price }}</span></p>
                                        <p class=\"discount-price\">Opis: <span>{{product.description}}</span></p>
                                    </article>
                                </div>
                            </div>

                        </section>


                        <section class=\"last-watched-products\">
                            <h2>Pregledani proizvodi</h2>
                            <div class=\"row\">
                                <div class=\"col-xs-6 col-sm-3 col-lg-2 \">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3 col-lg-2\">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3 col-lg-2 \">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3 col-lg-2\">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3 col-lg-2\">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                                <div class=\"col-xs-6 col-sm-3  col-lg-2 \">
                                    <article class=\"product\">
                                        <figure>
                                            <img src=\"img/products/sushi.thumb.jpeg\" alt=\"\"/>
                                        </figure>
                                        <p class=\"product-title\">Sushi</p>
                                        <a href=\"#\" class=\"more\">Detail</a>
                                    </article>
                                </div>
                            </div>
                        </section>
                    </div><!-- kraj levog kontejnera-->


                    <!-- ASIDE -->
                    <div class=\"col-md-3 aside\">
                        <section class=\"contact \">
                            <h3>Adresa:</h3>
                            <p>Bulevar Mihaila Pupina 181</p>
                            <p>11000 Beograd</p>
                            <p class=\"phone\"><span class=\"fa fa-phone\"></span> 011/123-123</p>
                            <p class=\"email\"><span class=\"fa fa-envelope-o\"></span><a href=\"mailto:example@mail.com\">example@mail.com</a></p>
                            <p class=\"url\"><span class=\"fa fa-globe\"></span><a href=\"http://school.cubes.rs\">school.cubes.rs</a></p>
                        </section>
                    </div><!-- Kraj aside -->

                </div>
            </div>
        </main><!--main end-->
    
{% endblock %}
{% block javascripts %}
    <script src=\"{{ asset('js/main.js')}}\" type=\"text/javascript\"></script>
    <link href=\"{{asset('css/bootstrap.min.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>
{% endblock %}
", "product/show.html.twig", "C:\\xampp\\htdocs\\symShop\\app\\Resources\\views\\product\\show.html.twig");
    }
}
